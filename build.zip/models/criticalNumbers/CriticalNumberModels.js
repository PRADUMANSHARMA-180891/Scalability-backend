const sequelize = require('../../Config/DBs');
const DataTypes = require('sequelize');

